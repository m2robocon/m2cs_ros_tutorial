#!/usr/bin/env python

import rospy
from pack1.srv import *

shift_val = 0.0

def callback(req):
    global shift_val

    rospy.loginfo("Setting shift to %f" % req.distance)
    shift_val = req.distance

    resp = SetDistanceSensorShiftResponse()
    resp.success = True
    resp.message = "shift update done"
    return resp

    # return ans

    # return AddTwoIntsResponse(sum = ans)

if __name__ == "__main__":
    rospy.init_node('distance_server')
    rospy.Service('distance_shift', SetDistanceSensorShift, callback)

    cur_f = 0.0
    
    r = rospy.Rate(10)

    while (not rospy.is_shutdown()):
        rospy.loginfo(cur_f + shift_val)
        cur_f += 0.01
        r.sleep()

