#!/usr/bin/env python

import rospy, random
from pack1.srv import *

if __name__ == "__main__":
    rospy.init_node('distance_caller')

    calc_client = rospy.ServiceProxy('distance_shift', SetDistanceSensorShift)

    r = rospy.Rate(1)

    while not rospy.is_shutdown():
        a = random.randint(0, 5)

        rospy.loginfo("Requesting %d" % a)

        req = SetDistanceSensorShiftRequest()
        req.distance = a

        resp = calc_client(req)

        rospy.loginfo("Response %d %s" % (resp.success, resp.message))

        r.sleep()
